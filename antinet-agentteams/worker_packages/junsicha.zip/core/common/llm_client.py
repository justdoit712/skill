"""LLMClient：材料智能体的 LLM 在环客户端（零外部依赖，仅用标准库）。

设计原则（对齐 AGENTS.md 第 3 节出域策略与降级铁律）：
- 优先调用本地 NPU 模型 Genie（端口 8910，OpenAI 兼容，无需 key），
  与后端 agents / hermes 使用同一个真实本地大模型。
- 次选 FreeLLMAPI（端口 9000，需 unified API key）。
- 两者皆不可达时返回 None，调用方必须如实降级为规则引擎，
  并在卡片/报告里标注 llm_involved=False（绝不允许静默冒充 LLM 已参与）。

本客户端不引入任何云端默认值；默认全部走本地。
"""
from __future__ import annotations
import json
import urllib.request
import urllib.error


class LLMClient:
    def __init__(
        self,
        model: str = "qwen2.5vl3b-8380-2.42",
        genie_url: str = "http://127.0.0.1:8910/v1/chat/completions",
        freellm_url: str = "http://localhost:9000/v1/chat/completions",
        freellm_key: str | None = None,
        timeout: int = 120,
    ):
        self.model = model
        self.genie_url = genie_url
        self.freellm_url = freellm_url
        self.freellm_key = freellm_key
        self.timeout = timeout
        self.used_llm = False        # 本轮是否真的调用了 LLM
        self.endpoint_used: str | None = None

    # ------------------------------------------------------------------
    def health(self) -> bool:
        """快速探活 Genie（本地 NPU 服务）。"""
        try:
            req = urllib.request.Request("http://127.0.0.1:8910/v1/models", method="GET")
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status == 200
        except Exception:
            return False

    # ------------------------------------------------------------------
    def chat(self, system: str, user: str, max_tokens: int = 512, temperature: float = 0.3) -> str | None:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": user})
        payload = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        # 1) 本地 Genie（主链路，与后端/hermes 同一模型）
        text = self._post(self.genie_url, payload, None)
        if text is not None:
            self.used_llm = True
            self.endpoint_used = "genie:8910"
            return text
        # 2) FreeLLMAPI（需 key）
        if self.freellm_key:
            text = self._post(self.freellm_url, payload, self.freellm_key)
            if text is not None:
                self.used_llm = True
                self.endpoint_used = "freellm:9000"
                return text
        return None

    # ------------------------------------------------------------------
    def _post(self, url: str, payload: dict, api_key: str | None) -> str | None:
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(url, data=data, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                resp = json.loads(r.read().decode("utf-8"))
            return resp["choices"][0]["message"]["content"]
        except Exception:
            return None


def extract_json(text: str) -> dict | None:
    """从模型输出中尽量稳健地抽取第一个 JSON 对象。"""
    if not text:
        return None
    s = text.find("{")
    e = text.rfind("}")
    if s == -1 or e == -1 or e <= s:
        return None
    try:
        return json.loads(text[s : e + 1])
    except Exception:
        return None
