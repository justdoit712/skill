#!/usr/bin/env python3
"""Worker 入口：加载 八官署运行时并执行本官署主链路阶段。"""
import os
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "core"))
from runtime import AgentSession
STAGE = "provenance"
if __name__ == "__main__":
    sess = AgentSession(HERE)
    sess.run_stage(STAGE)
