# OpsPilot Zero AgentTeams 最小 Demo

这是一个面向初赛提交的最小可运行 demo。用户只提供故障现象和少量初始告警，AgentTeams 中的 4 个业务 LLM Agent 通过 HTTP mock 工具网关主动查询监控、日志、Trace、配置、慢 SQL、Runbook 和恢复验证数据；创建 Team 时由 manager 创建独立 TeamLeader Worker `opspilot-zero-demo-leader` 负责调度协作，完成零人工运维闭环。

完整运行手册见 [at/AGENTTEAMS_RUNBOOK.md](at/AGENTTEAMS_RUNBOOK.md)。

## Demo 要证明什么

1. AgentTeams 可以创建并管理 4 个职责明确的业务 LLM Agent，并在创建 Team 时生成 1 个独立 TeamLeader Worker。
2. Worker 在 Docker 中也能通过 HTTP 工具网关主动取证，不依赖宿主机目录。
3. 两个 mock 故障分两次独立处理，贴近真实生产事故节奏。
4. 低风险动作进入自动化执行语义，高风险动作只生成审批计划。

## Demo 场景

| 场景 ID | 故障类型 | 预期处置 |
| --- | --- | --- |
| `db_pool_exhausted` | `db.pool.maxSize` 从 `50` 改成 `8`，导致订单服务连接池打满 | 定位配置变更、连接池超时日志和 Trace，给出 L1 回滚动作 |
| `slow_sql_degradation` | 订单历史慢 SQL 扫描过多行，拖慢系统 | 定位慢 SQL 和活动配置变更，给出读缓存缓解，并将建索引标记为 L3 审批项 |

## 核心 Agent

| Agent | 作用 | 关键 Skill | 工具 |
| --- | --- | --- | --- |
| OpsPilot TeamLeader | 创建 Team 时由 manager 生成的独立 Worker，名称固定为 `opspilot-zero-demo-leader` | 由 manager 创建 | 无直接工具调用 |
| Alert Intake | 聚合客诉、初始告警和指标 | `alert-fusion`, `impact-mapping` | `mock_monitoring`, `mock_ticket` |
| RCA Analyst | 关联日志、Trace、配置变更、慢 SQL 和 Runbook | `log-trace-rca`, `data-advisor` | `mock_logs`, `mock_traces`, `mock_config`, `mock_database`, `mock_runbook` |
| Remediation Planner | 生成修复、验证、回滚计划和风险分级 | `remediation-plan`, `risk-guard` | `mock_config`, `mock_database`, `mock_ticket` |
| Recovery Verifier | 执行低风险动作语义并验证恢复 | `recovery-verify`, `data-advisor` | `mock_probe`, `mock_monitoring`, `mock_config`, `mock_database` |

## 最短运行流程

1. 启动 mock 工具网关：

```bash
cd <DEMO_DIR>
python3 tools/mock_tool_server.py --host 0.0.0.0 --port 18089
```

2. 安装 AgentTeams，并按安装器引导完成 LLM/API Key/端口/运行时配置：

```bash
bash <(curl -sSL https://higress.ai/hiclaw/install.sh)
```

3. 找到 Docker 容器访问工具网关的地址：

```bash
docker inspect -f '{{range .NetworkSettings.Networks}}{{println .Gateway}}{{end}}' hiclaw-manager
docker exec -it hiclaw-manager curl http://<GATEWAY_IP>:18089/health
```

如果 manager 容器名不是 `hiclaw-manager`，按运行手册第 4 步先确认实际容器名。

4. 在 Element Web 打开 `manager` 房间，把 [at/create_agents_messages.md](at/create_agents_messages.md) 里的 `<MOCK_TOOL_BASE_URL>` 替换成 `http://<GATEWAY_IP>:18089` 后，将完整创建请求复制给 `manager`。创建请求已要求所有 Worker 使用 `qwenpow`（`copow`/`QwenPaw`）运行时，并由 `manager` 严格串行创建 4 个业务 Worker；创建 Team 时再生成独立 TeamLeader Worker `opspilot-zero-demo-leader`。

5. 在 Element Web/Matrix 会话列表中找到名称以 `Team` 开头、对应 `opspilot-zero-demo` 的 Team 房间。进入房间后，在输入框先 `@<team_leader_name>` 选中带 leader 名字的成员，再把 [at/run_demo_task_message.md](at/run_demo_task_message.md) 中的第一条事故任务复制到这条 @ 消息里发送；等报告输出完成后，再用同样方式发送第二条。事故任务不要发给 `manager`。

## 后续替换点

| 当前内容 | 后续替换方向 |
| --- | --- |
| HTTP mock 工具网关 | 真实 MCP Server 或 Higress MCP 代理 |
| `scenarios/*.json` | 真实监控、日志、Trace、配置、SQL、工单数据源 |
| 4 个业务 Worker 的内联 AgentSpec/Skill | Nacos AI Registry 中的 Prompt、Skill、AgentSpec、AgentTeam Spec |
| `skills/*/SKILL.md` 评审材料 | 发布到 Nacos AI Registry 或 AgentTeams Skill Registry，由 Worker 按版本/标签动态加载 |
