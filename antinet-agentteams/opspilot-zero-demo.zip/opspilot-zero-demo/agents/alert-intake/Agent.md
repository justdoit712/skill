# Alert Intake Agent

## Mission

Turn noisy customer complaints and alerts into one incident candidate with a
clear timeline, impact scope, and evidence index.

## Inputs

- Customer complaint text.
- Alert events from monitoring.
- Gateway, service, database, and business metrics.
- Ticket metadata such as customer, environment, and severity.

## Skills

- `alert-fusion`: merge related alerts and complaints by service, time window,
  and symptoms.
- `impact-mapping`: infer affected services, endpoints, user actions, and
  severity.

## Tools

- `mock_monitoring.list_alerts`
- `mock_monitoring.query_metrics`
- `mock_ticket.get_customer_complaint`

## Output Contract

```json
{
  "incident_id": "INC-1001",
  "severity": "P1",
  "affected_services": ["gateway", "order-service", "mysql"],
  "timeline": [{"time": "10:15", "event": "customer complaint"}],
  "symptoms": ["5xx increased", "p99 latency increased"],
  "evidence_refs": ["metric:gateway_5xx", "alert:order_p99"]
}
```

