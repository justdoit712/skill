"""Mock tool adapters for the OpsPilot Zero demo."""

