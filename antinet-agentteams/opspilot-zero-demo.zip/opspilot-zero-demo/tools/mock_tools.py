from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCENARIO_DIR = PROJECT_ROOT / "scenarios"


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def list_scenarios() -> List[str]:
    return sorted(path.stem for path in SCENARIO_DIR.glob("*.json"))


def load_scenario(scenario_id: str) -> Dict[str, Any]:
    path = SCENARIO_DIR / f"{scenario_id}.json"
    if not path.exists():
        available = ", ".join(list_scenarios())
        raise ValueError(f"Unknown scenario '{scenario_id}'. Available: {available}")
    return load_json(path)


def compact(value: Any, max_len: int = 180) -> str:
    text = json.dumps(value, ensure_ascii=False, sort_keys=True)
    return text if len(text) <= max_len else text[: max_len - 3] + "..."


def endpoint_p99(metrics: Dict[str, Any], endpoint: str) -> int:
    if "order/history" in endpoint and "order_history_p99_ms" in metrics:
        return int(metrics["order_history_p99_ms"])
    if "order/create" in endpoint and "order_create_p99_ms" in metrics:
        return int(metrics["order_create_p99_ms"])
    return int(min((metrics[key] for key in metrics if key.endswith("_p99_ms")), default=0))


class BaseMockTools:
    def __init__(self, scenario_id: str) -> None:
        self.scenario_id = scenario_id
        self.actions: List[Dict[str, Any]] = []
        self.trace: List[Dict[str, Any]] = []

    def _record(self, tool: str, args: Dict[str, Any], result: Any) -> Any:
        self.trace.append(
            {
                "time": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "tool": tool,
                "args": args,
                "result_preview": compact(result),
            }
        )
        return result

    def reset(self) -> None:
        self.actions.clear()
        self.trace.clear()

    def get_customer_complaint(self) -> Dict[str, Any]:
        raise NotImplementedError

    def list_alerts(self) -> List[Dict[str, Any]]:
        raise NotImplementedError

    def query_metrics(self, phase: str = "before") -> Dict[str, Any]:
        raise NotImplementedError

    def search_logs(self, keyword: Optional[str] = None) -> List[Dict[str, Any]]:
        raise NotImplementedError

    def query_traces(self, endpoint: Optional[str] = None) -> List[Dict[str, Any]]:
        raise NotImplementedError

    def list_config_changes(self) -> List[Dict[str, Any]]:
        raise NotImplementedError

    def list_slow_queries(self) -> List[Dict[str, Any]]:
        raise NotImplementedError

    def search_runbooks(self, query: Optional[str] = None) -> List[Dict[str, Any]]:
        raise NotImplementedError

    def rollback_config(self, action: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    def enable_read_cache(self, endpoint: str) -> Dict[str, Any]:
        raise NotImplementedError

    def create_index_plan(self, slow_query: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    def create_approval_task(self, title: str, details: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    def check_endpoint(self, endpoint: str) -> Dict[str, Any]:
        raise NotImplementedError


class LocalMockTools(BaseMockTools):
    def __init__(self, scenario_id: str) -> None:
        super().__init__(scenario_id)
        self.scenario = load_scenario(scenario_id)

    def _scenario(self, key: str, default: Any) -> Any:
        return self.scenario.get(key, default)

    def get_customer_complaint(self) -> Dict[str, Any]:
        return self._record("mock_ticket.get_customer_complaint", {}, self.scenario["complaint"])

    def list_alerts(self) -> List[Dict[str, Any]]:
        return self._record("mock_monitoring.list_alerts", {}, self._scenario("alerts", []))

    def query_metrics(self, phase: str = "before") -> Dict[str, Any]:
        metrics = self.scenario["metrics"]
        selected = metrics["after_expected"] if phase == "after" and self.actions else metrics["before"]
        return self._record("mock_monitoring.query_metrics", {"phase": phase}, selected)

    def search_logs(self, keyword: Optional[str] = None) -> List[Dict[str, Any]]:
        logs = self._scenario("logs", [])
        if keyword:
            lowered = keyword.lower()
            logs = [row for row in logs if lowered in row.get("message", "").lower()]
        return self._record("mock_logs.search_logs", {"keyword": keyword}, logs)

    def query_traces(self, endpoint: Optional[str] = None) -> List[Dict[str, Any]]:
        traces = self._scenario("traces", [])
        if endpoint:
            traces = [row for row in traces if row.get("endpoint") == endpoint]
        return self._record("mock_traces.query_traces", {"endpoint": endpoint}, traces)

    def list_config_changes(self) -> List[Dict[str, Any]]:
        return self._record("mock_config.list_changes", {}, self._scenario("config_changes", []))

    def list_slow_queries(self) -> List[Dict[str, Any]]:
        return self._record("mock_database.list_slow_queries", {}, self._scenario("slow_queries", []))

    def search_runbooks(self, query: Optional[str] = None) -> List[Dict[str, Any]]:
        runbooks = self._scenario("runbooks", [])
        if query:
            lowered = query.lower()
            runbooks = [
                row
                for row in runbooks
                if lowered in row.get("title", "").lower()
                or any(lowered in term.lower() for term in row.get("match_terms", []))
            ]
        return self._record("mock_runbook.search", {"query": query}, runbooks)

    def rollback_config(self, action: Dict[str, Any]) -> Dict[str, Any]:
        result = {
            "status": "success",
            "action": "rollback_config",
            "target": action.get("target"),
            "key": action.get("key"),
            "value": action.get("value"),
            "message": "Mock Nacos config rollback applied.",
        }
        self.actions.append(result)
        return self._record("mock_config.rollback_config", action, result)

    def enable_read_cache(self, endpoint: str) -> Dict[str, Any]:
        result = {
            "status": "success",
            "action": "enable_read_cache",
            "endpoint": endpoint,
            "ttl_seconds": 60,
            "message": "Mock read cache enabled for hot query endpoint.",
        }
        self.actions.append(result)
        return self._record("mock_database.enable_read_cache", {"endpoint": endpoint}, result)

    def create_index_plan(self, slow_query: Dict[str, Any]) -> Dict[str, Any]:
        result = {
            "status": "planned",
            "action": "create_index_plan",
            "risk_level": slow_query.get("risk_level", "L3"),
            "sql": slow_query.get("suggested_index"),
            "message": "Index creation plan generated. Approval is required before execution.",
        }
        return self._record("mock_database.create_index_plan", {"digest": slow_query.get("digest")}, result)

    def create_approval_task(self, title: str, details: Dict[str, Any]) -> Dict[str, Any]:
        result = {
            "status": "created",
            "ticket_id": f"APPROVAL-{self.scenario_id.upper()}",
            "title": title,
            "details": details,
        }
        return self._record("mock_ticket.create_approval_task", {"title": title}, result)

    def check_endpoint(self, endpoint: str) -> Dict[str, Any]:
        metrics = self.query_metrics("after" if self.actions else "before")
        p99 = endpoint_p99(metrics, endpoint)
        result = {
            "endpoint": endpoint,
            "status": "ok" if self.actions and p99 < 2500 else "degraded",
            "p99_ms": p99,
            "message": "Synthetic probe passed." if self.actions and p99 < 2500 else "Synthetic probe still sees degradation.",
        }
        return self._record("mock_probe.check_endpoint", {"endpoint": endpoint}, result)


def max_severity(alerts: Iterable[Dict[str, Any]]) -> str:
    order = {"P0": 0, "P1": 1, "P2": 2, "P3": 3, "P4": 4}
    severities = [alert.get("severity", "P4") for alert in alerts]
    return min(severities, key=lambda item: order.get(item, 99), default="P4")
