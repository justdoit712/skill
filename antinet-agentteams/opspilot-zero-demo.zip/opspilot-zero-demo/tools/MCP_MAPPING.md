# MCP Mapping Notes

初赛 demo 使用 HTTP mock tool gateway，让 AgentTeams 中的 Docker Worker 可以通过网络访问 mock 监控、日志、Trace、配置、数据库、探针和工单工具。

当前工具网关不是 MCP Server，但每个 HTTP 工具都有明确的未来 MCP 映射。后续只需要把 HTTP endpoint 替换为真实 MCP Server 或 Higress MCP 代理，Agent 的 Prompt/Skill/工具契约可以保持稳定。

## HTTP 调用协议

```text
POST http://<MOCK_TOOL_BASE_URL>/tools/{scenario_id}/{tool_name}.{function_name}
Content-Type: application/json
```

示例：

```bash
curl -X POST http://127.0.0.1:18089/tools/db_pool_exhausted/mock_monitoring.list_alerts \
  -H 'Content-Type: application/json' \
  -d '{}'
```

## 工具映射

| HTTP mock tool | Demo function | Future MCP tool |
| --- | --- | --- |
| `mock_monitoring` | `list_alerts`, `query_metrics` | `monitoring.list_alerts`, `monitoring.query_metrics` |
| `mock_logs` | `search_logs` | `log.search` |
| `mock_traces` | `query_traces` | `trace.query` |
| `mock_config` | `list_changes`, `rollback_config` | `nacos.config.query`, `nacos.config.rollback` |
| `mock_database` | `list_slow_queries`, `enable_read_cache`, `create_index_plan` | `database.diagnostics`, `database.mitigation`, `database.plan_change` |
| `mock_probe` | `check_endpoint` | `synthetic_probe.check` |
| `mock_ticket` | `get_customer_complaint`, `create_approval_task` | `ticket.query`, `ticket.create_or_update` |
| `mock_runbook` | `search` | `knowledge.runbook_search` |
