# AgentTeams 事故任务消息

4 个业务 Worker、独立 TeamLeader Worker `opspilot-zero-demo-leader` 以及 `opspilot-zero-demo` Team 创建完成后，在 Element Web/Matrix 会话列表中找到名称以 `Team` 开头、对应 `opspilot-zero-demo` 的 Team 房间。

进入 Team 房间后，在输入框先输入并选中 `@<team_leader_name>`，再把下面的事故任务复制到这条 @ 消息里发送。不要把事故任务发给 `manager`。`manager` 用于创建和管理 Agent/Team；Team 房间中的 leader 用于接收业务任务并调度 Worker。

请逐个任务发送：先发送第一起事故，等 `INC-1001` 事故报告完整输出后，再发送第二起事故。不要同时发送两条事故任务，避免 Team 并发调度时上下文和工具状态互相干扰。

每条消息只包含用户能自然提供的故障现象和少量初始告警。日志、Trace、配置变更、慢 SQL、Runbook、恢复指标等信息应由 Agent 通过工具网关主动查询。

## 第一次任务：订单创建失败

```text
@<team_leader_name>

请让你的 Team 处理一条新的生产故障。

incident_id: INC-1001
scenario_id: db_pool_exhausted
客户：杭州示例电商
联系人：张三
环境：kubernetes + nacos + higress + mysql

故障现象：
10:15 起，用户提交订单后支付页一直转圈，客服反馈订单创建失败明显增加。

初始告警：
- 10:16 higress-gateway gateway_5xx_rate_high P1 18.4%
- 10:16 order-service order_create_p99_high P1 6800ms
- 10:17 order-service db_connection_pool_active_ratio_high P1 0.99

请开始排查和处置，并输出本次事故报告。
```

## 第二次任务：订单历史页很慢

第一起事故报告输出完成后，再单独发送下面这条消息。

```text
@<team_leader_name>

请让你的 Team 处理一条新的生产故障。

incident_id: INC-1002
scenario_id: slow_sql_degradation
客户：上海示例零售
联系人：李四
环境：kubernetes + nacos + ingress + mysql

故障现象：
14:05 起，午间活动后订单历史页打开很慢；用户仍可下单，但客服投诉明显增多。

初始告警：
- 14:06 order-service order_history_p99_high P2 9200ms
- 14:07 mysql mysql_cpu_high P2 88%
- 14:08 mysql slow_sql_count_high P2 142 queries/min

请开始排查和处置，并输出本次事故报告。
```
