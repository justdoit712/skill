# OpsPilot Zero Demo AgentTeam

这个文件描述 demo 使用的 Team 形态。主运行路径是 AgentTeams + 真实 LLM Worker + HTTP mock 工具网关。

## AgentTeams 运行时

| AgentTeams 概念 | Demo 设计 |
| --- | --- |
| Manager 房间 | 接收自包含的 Agent 创建消息 |
| Team 房间 | Matrix 会话列表中名称以 `Team` 开头；用户通过 `@<team_leader_name>` 发送事故任务 |
| TeamLeader Worker | 创建 Team 时由 manager 生成的独立 Worker `opspilot-zero-demo-leader` |
| Worker 房间 | 运行 4 个角色明确的业务 LLM Agent |
| Worker 运行时 | 统一使用 `qwenpow`（`copow`/`QwenPaw`） |
| 创建策略 | `manager` 串行创建 4 个业务 Worker；创建 Team 时再生成独立 TeamLeader Worker `opspilot-zero-demo-leader`；禁止把业务 Worker 指定为 leader |
| AgentSpec | 4 个业务 Worker 内联在 `at/create_agents_messages.md` |
| 事故输入 | `at/run_demo_task_message.md` 中的故障现象和初始告警 |
| 工具调用 | HTTP mock 工具网关 |
| Skill Registry | 当前运行时使用创建消息中的内联 Skill 语义；`skills/*/SKILL.md` 和 `at/nacos_registry_mock.json` 用于评审和后续替换 |

AgentTeams 组件经常运行在 Docker 中，因此运行时不依赖宿主机上的项目目录路径。Worker 通过 HTTP 地址访问工具网关，并根据 `scenario_id` 查询对应事故数据。当前 demo 不要求 Worker 读取宿主机上的 `skills/*/SKILL.md`；后续可把这些 Skill 发布到 Nacos AI Registry 或 AgentTeams Skill Registry，再由 Worker 按版本/标签动态加载。

## 工作流

1. TeamLeader `opspilot-zero-demo-leader` 接收 Team 房间中的事故任务，提取 `incident_id`、`scenario_id` 和用户描述，并调度业务 Worker。
2. `Alert Intake Agent` 读取客诉、初始告警和核心指标，生成事故候选、时间线和影响面。
3. `RCA Analyst Agent` 主动查询日志、Trace、配置变更、慢 SQL 和 Runbook，输出根因候选和证据链。
4. `Remediation Planner Agent` 生成修复计划、风险等级、审批策略、验证步骤和回滚点。
5. `Recovery Verifier Agent` 执行低风险动作语义，查询恢复指标和探针结果，输出复盘与数据采集建议；TeamLeader 汇总最终事故报告。

## Demo 场景

| 场景 | 根因 | 安全策略 |
| --- | --- | --- |
| `db_pool_exhausted` | `db.pool.maxSize` 从 `50` 改为 `8`，导致 DB 连接池耗尽。 | 配置回滚视为 L1 可逆动作。 |
| `slow_sql_degradation` | 订单历史慢 SQL 拖高 MySQL CPU 和接口 p99。 | 读缓存作为 L1 缓解，建索引作为 L3 审批项。 |
