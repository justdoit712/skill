---
name: risk-guard
description: Classify remediation action risk and decide whether an action may be auto-executed or must become an approval task.
metadata:
  version: "0.1.0"
  maturity: demo
---

# Risk Guard

## Purpose

Use this skill before any remediation action is executed. It protects the demo from treating risky production changes as automatic operations.

## Inputs

- Proposed action type and target.
- Reversibility and blast radius.
- Data, schema, or traffic impact.
- Existing approval or rollback point.

## Risk Levels

| Level | Meaning | Demo behavior |
| --- | --- | --- |
| L0 | Read-only diagnosis | Always allowed |
| L1 | Reversible low-risk action | Auto-executable in mock mode |
| L2 | Gray release or partial production impact | Approval task required |
| L3 | Data, schema, destructive, or hard-to-rollback operation | Approval task required, never auto-execute |

## Procedure

1. Classify the action by risk level.
2. Check whether rollback is known and fast.
3. Decide `auto_allowed`.
4. If approval is required, generate the reason and required approver role.
5. Pass the decision to Remediation Planner and Recovery Verifier.

## Output Contract

```json
{
  "risk_level": "L3",
  "auto_allowed": false,
  "approval_reason": "database schema/index change requires DBA review",
  "required_approver": "DBA"
}
```

## Guardrails

- Schema changes, data deletion, irreversible actions, and broad traffic shifts are never auto-executed.
- Reversible config rollback may be L1 only when the previous value and validation plan are known.
- When uncertainty is high, choose the safer higher risk level.
