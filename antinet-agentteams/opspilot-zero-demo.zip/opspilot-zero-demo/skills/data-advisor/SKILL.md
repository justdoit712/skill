---
name: data-advisor
description: Identify missing observability, audit, and diagnostic data after an OpsPilot Zero RCA or recovery verification step.
metadata:
  version: "0.1.0"
  maturity: demo
---

# Data Advisor

## Purpose

Use this skill when an agent has enough evidence to respond to an incident but also needs to recommend better data collection for future accuracy.

## Inputs

- Root-cause candidate and evidence chain.
- Missing evidence noted during RCA.
- Remediation and verification results.
- Existing metrics, logs, traces, config records, SQL diagnostics, and runbook matches.

## Procedure

1. Compare the incident conclusion with the available evidence types.
2. Identify which missing signals would have reduced uncertainty or time to diagnosis.
3. Prioritize recommendations that are low overhead and directly tied to the incident class.
4. Separate must-have telemetry from nice-to-have enrichment.
5. Output concrete data names rather than generic advice.

## Recommended Data Patterns

- Config change audit: operator, timestamp, old value, new value, rollout scope, approval reason.
- Connection pool telemetry: active/idle counts, wait-time histogram, timeout count, configured max size.
- Trace enrichment: endpoint, database span duration, status, sampled slow traces during incidents.
- Slow SQL diagnostics: digest, execution plan, rows examined, index usage, table cardinality.
- Recovery validation: before/after metrics, synthetic probe result, rollback readiness.

## Output Contract

```json
{
  "must_have": ["connection pool wait-time histogram"],
  "nice_to_have": ["database max_connections configured value and change history"],
  "reasoning": ["wait-time histogram would distinguish pool starvation from slow database execution"]
}
```

## Quality Gates

- Recommendations must reference a concrete gap observed in the incident.
- Do not recommend collecting sensitive payload data unless the incident requires it.
- Prefer stable telemetry contracts over one-off manual collection.
