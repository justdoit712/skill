---
name: recovery-verify
description: Verify whether an approved remediation or mitigation actually restored user-facing and technical health signals.
metadata:
  version: "0.1.0"
  maturity: demo
---

# Recovery Verify

## Purpose

Use this skill after remediation planning to validate recovery, record residual risk, and produce postmortem notes.

## Inputs

- Executed low-risk actions.
- Approval-only actions and their ticket IDs.
- Before and after metrics.
- Synthetic probe results.
- RCA and remediation plan.

## Procedure

1. Confirm which actions were executed and which were approval-only.
2. Query after-action metrics and endpoint probes.
3. Compare recovery criteria with before/after values.
4. Decide `recovered`, `needs_attention`, or `approval_pending`.
5. Produce postmortem notes and follow-up telemetry recommendations.

## Output Contract

```json
{
  "recovered": true,
  "executed_actions": ["rollback_config"],
  "approval_actions": [],
  "verification": [{"metric": "order_create_p99_ms", "before": 6800, "after": 420}],
  "residual_risks": [],
  "postmortem_notes": ["configuration change reduced DB pool size below the expected configured value"]
}
```

## Quality Gates

- Recovery must be based on user-facing probes or business-critical metrics, not only tool success.
- Approval-only actions must not be reported as executed.
- If after metrics are missing, mark recovery as unverified.
