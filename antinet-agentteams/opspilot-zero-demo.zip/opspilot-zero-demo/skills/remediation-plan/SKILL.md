---
name: remediation-plan
description: Convert an RCA result into ordered remediation, validation, rollback, and approval steps for OpsPilot Zero.
metadata:
  version: "0.1.0"
  maturity: demo
---

# Remediation Plan

## Purpose

Use this skill when an agent needs to turn the top root-cause candidate into a safe, executable incident response plan.

## Inputs

- Top root-cause candidate and confidence.
- Evidence chain and matched runbook.
- Available rollback point or mitigation.
- Risk decision from `risk-guard`.

## Procedure

1. Select the smallest action that can reduce customer impact.
2. Define validation metrics and probes before execution.
3. Define rollback point and rollback trigger.
4. Separate auto-executable actions from approval-only actions.
5. Produce an ordered plan that Recovery Verifier can execute or validate.

## Output Contract

```json
{
  "actions": [
    {
      "id": "A1",
      "type": "rollback_config",
      "risk_level": "L1",
      "auto_allowed": true,
      "reason": "reversible rollback to last known good config"
    }
  ],
  "validation": ["probe /api/order/create", "check order_create_p99_ms < 1000"],
  "rollback_point": "restore previous value if recovery regresses",
  "approval_required_actions": []
}
```

## Quality Gates

- Do not plan destructive or schema-changing actions as auto-executable.
- Every action must have validation and rollback guidance.
- Prefer reversible mitigation before long-term optimization.
