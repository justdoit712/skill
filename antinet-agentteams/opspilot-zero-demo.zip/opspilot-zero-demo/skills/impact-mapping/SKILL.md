---
name: impact-mapping
description: Map fused alert clusters to affected services, endpoints, user actions, and initial incident severity.
metadata:
  version: "0.1.0"
  maturity: demo
---

# Impact Mapping

## Purpose

Use this skill after alert fusion to turn technical symptoms into an operator-friendly impact summary.

## Inputs

- Alert cluster from `alert-fusion`.
- Customer complaint and business context.
- Gateway, application, database, and business metrics.
- Known service-to-endpoint mapping if available.

## Procedure

1. Identify affected services and endpoints from alert service names, traces, and complaint text.
2. Map endpoint symptoms to user-visible actions such as order creation or order history query.
3. Assign initial severity based on customer impact, error rate, p99 latency, and business criticality.
4. Produce a short impact summary suitable for the leader and downstream agents.
5. Mark uncertainty when the mapping depends on incomplete telemetry.

## Output Contract

```json
{
  "affected_services": ["higress-gateway", "order-service", "mysql"],
  "affected_endpoints": ["/api/order/create"],
  "affected_user_actions": ["submit order", "payment redirect"],
  "severity": "P1",
  "impact_summary": "Order creation is failing for customer-facing traffic.",
  "data_gaps": []
}
```

## Quality Gates

- Do not infer a user action unless it is supported by complaint text, endpoint data, or runbook mapping.
- Severity must explain both technical signal and user impact.
- Preserve uncertainty explicitly instead of hiding it in the summary.
