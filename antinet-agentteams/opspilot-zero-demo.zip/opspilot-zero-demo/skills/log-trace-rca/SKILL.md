---
name: log-trace-rca
description: Correlate logs, traces, metrics, config changes, slow SQL, and runbooks to rank evidence-backed root-cause candidates.
metadata:
  version: "0.1.0"
  maturity: demo
---

# Log Trace RCA

## Purpose

Use this skill when an agent must move from incident symptoms to ranked root-cause candidates with explicit evidence.

## Inputs

- Incident summary from Alert Intake.
- Logs, traces, metrics, config changes, slow SQL records, and runbook matches.
- Time window and affected service or endpoint.

## Procedure

1. Align all evidence on the incident time window.
2. Identify correlated changes, errors, slow spans, and database symptoms.
3. Build root-cause candidates and attach evidence from at least two independent sources when possible.
4. Score confidence based on temporal alignment, specificity, and evidence diversity.
5. Record missing evidence and alternative hypotheses.

## Candidate Scoring

| Signal | Confidence impact |
| --- | --- |
| Change immediately before incident | High |
| Error log matching symptom | High |
| Trace span localizes latency | High |
| Metric anomaly only | Medium |
| Runbook match only | Medium |
| Single weak signal | Low |

## Output Contract

```json
{
  "top_candidate": {
    "root_cause": "db_pool_exhausted",
    "confidence": 0.91,
    "evidence": ["config db.pool.maxSize changed 50 -> 8", "logs show connection pool timeout"]
  },
  "candidates": [],
  "missing_evidence": ["connection pool wait-time histogram"]
}
```

## Guardrails

- Do not produce a strong root cause from a single evidence item.
- Do not confuse mitigation success with root-cause proof.
- Every conclusion must cite evidence or be labeled as a hypothesis.
