---
name: alert-fusion
description: Fuse customer complaints, monitoring alerts, and high-level metrics into a single incident candidate for OpsPilot Zero triage.
metadata:
  version: "0.1.0"
  maturity: demo
---

# Alert Fusion

## Purpose

Use this skill when an agent receives noisy customer complaints, alerts, and metric snapshots and must decide whether they describe one incident or separate events.

## Inputs

- Customer complaint text and timestamp.
- Alert list with service, severity, metric name, value, unit, and timestamp.
- Before-incident metric snapshot.
- Optional ticket metadata such as customer, environment, and owner.

## Procedure

1. Normalize timestamps, service names, endpoint names, and severity labels.
2. Group signals that share a time window, affected service, endpoint, or symptom.
3. Derive the primary incident candidate with severity, affected services, symptoms, and timeline.
4. Preserve every source reference so downstream RCA can cite the evidence.
5. If key fields are missing, keep the signal but add a data gap instead of discarding it.

## Output Contract

```json
{
  "severity": "P1",
  "affected_services": ["order-service"],
  "timeline": [{"time": "10:16", "event": "order_create_p99_high", "evidence_ref": "alert:ALERT-1002"}],
  "symptoms": ["order-service::order_create_p99_high=6800ms"],
  "evidence_refs": ["alert:ALERT-1002"],
  "data_gaps": []
}
```

## Quality Gates

- Do not merge unrelated alerts only because they are close in time.
- Do not downgrade severity when user-facing impact and P1 alerts are present.
- Every symptom must map back to an alert, complaint, or metric source.
